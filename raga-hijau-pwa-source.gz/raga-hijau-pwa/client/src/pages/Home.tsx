import { useEffect, useMemo, useState } from "react";
import {
  Activity,
  ArrowUpRight,
  Check,
  ChevronRight,
  CircleDot,
  Clock3,
  Droplets,
  Flame,
  HeartPulse,
  Moon,
  Plus,
  RotateCcw,
  Sparkles,
  Target,
  Trash2,
  Trophy,
  Utensils,
  Zap,
} from "lucide-react";

type Tab = "overview" | "training" | "health";
type Intensity = "ringan" | "sedang" | "berat";
type Mood = "tenang" | "netral" | "lelah" | "berat";

type Workout = {
  id: string;
  date: string;
  activity: string;
  duration: number;
  intensity: Intensity;
  note: string;
};

type RagaState = {
  water: number;
  sleep: number;
  mood: Mood | null;
  healthNote: string;
  workouts: Workout[];
};

const STORAGE_KEY = "raga-hijau-mvp-v1";
const AVATAR_URL = "https://ruangtumbuh-7wc6sasx.manus.space/manus-storage/avatar-icon_f141168e.jpg";
const todayKey = () => new Date().toISOString().slice(0, 10);
const initialState: RagaState = { water: 0, sleep: 7, mood: null, healthNote: "", workouts: [] };

const intensityLabels: Record<Intensity, string> = { ringan: "Ringan", sedang: "Sedang", berat: "Berat" };
const moodLabels: Record<Exclude<Mood, null>, string> = {
  tenang: "Tenang",
  netral: "Netral",
  lelah: "Lelah",
  berat: "Berat",
};

function readState(): RagaState {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (!stored) return initialState;
    return { ...initialState, ...JSON.parse(stored) };
  } catch {
    return initialState;
  }
}

function todayLabel() {
  return new Intl.DateTimeFormat("id-ID", { weekday: "long", day: "numeric", month: "long" }).format(new Date());
}

function MetricCard({ icon, label, value, detail, tone }: { icon: React.ReactNode; label: string; value: string; detail: string; tone: string }) {
  return (
    <article className={`metric-card metric-card--${tone}`}>
      <div className="metric-icon">{icon}</div>
      <p>{label}</p>
      <strong>{value}</strong>
      <span>{detail}</span>
    </article>
  );
}

function ProgressRing({ value, max, label }: { value: number; max: number; label: string }) {
  const percentage = Math.min(100, Math.round((value / max) * 100));
  return (
    <div className="progress-ring" style={{ "--progress": `${percentage * 3.6}deg` } as React.CSSProperties}>
      <div className="progress-ring__inner"><strong>{percentage}%</strong><span>{label}</span></div>
    </div>
  );
}

export default function Home() {
  const [tab, setTab] = useState<Tab>("overview");
  const [state, setState] = useState<RagaState>(readState);
  const [savedPulse, setSavedPulse] = useState(false);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  }, [state]);

  const todayWorkouts = useMemo(() => state.workouts.filter((workout) => workout.date === todayKey()), [state.workouts]);
  const totalMinutes = todayWorkouts.reduce((sum, workout) => sum + workout.duration, 0);
  const waterGoal = 8;
  const sleepGoal = 8;

  function updateState(patch: Partial<RagaState>) {
    setState((current) => ({ ...current, ...patch }));
    setSavedPulse(true);
    window.setTimeout(() => setSavedPulse(false), 700);
  }

  function addWater(amount: number) {
    updateState({ water: Math.max(0, Math.min(waterGoal, state.water + amount)) });
  }

  function addWorkout(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    const activity = String(form.get("activity") || "").trim();
    const duration = Number(form.get("duration") || 0);
    if (!activity || !duration) return;
    const workout: Workout = {
      id: `${Date.now()}`,
      date: todayKey(),
      activity,
      duration,
      intensity: (form.get("intensity") as Intensity) || "sedang",
      note: String(form.get("note") || "").trim(),
    };
    updateState({ workouts: [workout, ...state.workouts] });
    event.currentTarget.reset();
  }

  function removeWorkout(id: string) {
    updateState({ workouts: state.workouts.filter((workout) => workout.id !== id) });
  }

  const tabs: { id: Tab; label: string; icon: React.ReactNode }[] = [
    { id: "overview", label: "Ringkasan", icon: <Sparkles size={16} /> },
    { id: "training", label: "Latihan", icon: <Activity size={16} /> },
    { id: "health", label: "Kesehatan", icon: <HeartPulse size={16} /> },
  ];

  return (
    <div className={`raga-app ${savedPulse ? "raga-app--saved" : ""}`}>
      <aside className="sidebar">
        <div className="brand-lockup">
          <img src={AVATAR_URL} alt="Ikon karakter Raga Hijau" />
          <div><span>RAGA</span><strong>Hijau</strong></div>
        </div>
        <div className="sidebar-note"><CircleDot size={13} /> <span>Ruang untuk tubuh yang hidup.</span></div>
        <nav className="side-nav" aria-label="Navigasi utama">
          {tabs.map((item) => <button key={item.id} className={tab === item.id ? "is-active" : ""} onClick={() => setTab(item.id)}>{item.icon}<span>{item.label}</span></button>)}
        </nav>
        <div className="sidebar-footer"><span className="status-dot" /> Disimpan di perangkatmu<div className="sidebar-quote">"Rawat tubuhmu seperti rumah yang ingin kamu tinggali lama."</div></div>
      </aside>

      <main className="main-content">
        <header className="topbar">
          <div><p className="eyebrow">{todayLabel()}</p><h1>{tab === "overview" ? "Ruang tenang untuk bergerak." : tab === "training" ? "Latihan yang bisa kamu jalani." : "Dengarkan sinyal tubuh."}</h1></div>
          <div className="topbar-actions"><span className="offline-badge"><span className="status-dot" /> Offline ready</span><img src={AVATAR_URL} alt="Profil" /></div>
        </header>

        <div className="mobile-tabs">{tabs.map((item) => <button key={item.id} className={tab === item.id ? "is-active" : ""} onClick={() => setTab(item.id)}>{item.icon}{item.label}</button>)}</div>

        {tab === "overview" && <>
          <section className="hero-panel">
            <div className="hero-copy"><p className="eyebrow">CATATAN HARI INI · 01</p><h2>Gerak kecil tetap meninggalkan jejak.</h2><p>Gunakan ruang ini untuk memperhatikan energimu, bukan untuk menghukum diri. Satu langkah yang terasa masuk akal sudah cukup untuk mulai.</p><button className="primary-button" onClick={() => setTab("training")}>Catat latihan <ArrowUpRight size={16} /></button></div>
            <div className="hero-art"><div className="glow-orb" /><img src={AVATAR_URL} alt="Karakter Raga Hijau" /><span className="hero-tag hero-tag--one">napas</span><span className="hero-tag hero-tag--two">bergerak</span><span className="hero-tag hero-tag--three">pulih</span></div>
          </section>
          <section className="section-block"><div className="section-heading"><div><p className="eyebrow">PEMETAAN HARI INI</p><h2>Bagaimana ragamu?</h2></div><span className="section-caption">data pribadi, tanpa penilaian</span></div><div className="metric-grid"><MetricCard icon={<Flame size={17} />} label="Gerak" value={`${totalMinutes} m`} detail={`${todayWorkouts.length} sesi hari ini`} tone="lime" /><MetricCard icon={<Droplets size={17} />} label="Hidrasi" value={`${state.water}/8`} detail="gelas tercatat" tone="teal" /><MetricCard icon={<Moon size={17} />} label="Tidur" value={`${state.sleep}j`} detail={state.sleep >= sleepGoal ? "cukup untuk hari ini" : "beri ruang untuk pulih"} tone="moss" /></div></section>
          <section className="split-grid"><article className="dark-panel"><div className="panel-heading"><div><p className="eyebrow">RITME LATIHAN</p><h2>Intensitas hari ini</h2></div><ProgressRing value={totalMinutes} max={60} label="target" /></div><div className="intensity-track"><span style={{ width: `${Math.min(100, (totalMinutes / 60) * 100)}%` }} /></div><div className="track-labels"><span>0 menit</span><span>60 menit</span></div><p className="panel-note">Tidak perlu mengejar angka. Perhatikan bagaimana tubuhmu terasa setelah bergerak.</p></article><article className="quote-panel"><span className="quote-mark">✦</span><p>“Konsistensi bukan berarti selalu kuat. Kadang ia hanya berarti kembali dengan lembut.”</p><button className="text-button" onClick={() => setTab("health")}>Buka check-in <ChevronRight size={15} /></button></article></section>
          <section className="section-block"><div className="section-heading"><div><p className="eyebrow">CATATAN GERAK</p><h2>Sesi terbaru</h2></div><button className="text-button" onClick={() => setTab("training")}>Lihat semua <ChevronRight size={15} /></button></div>{todayWorkouts.length ? <div className="workout-list">{todayWorkouts.slice(0, 3).map((workout) => <WorkoutRow key={workout.id} workout={workout} onDelete={removeWorkout} />)}</div> : <EmptyState onAdd={() => setTab("training")} />}</section>
        </>}

        {tab === "training" && <section className="page-layout"><div className="section-heading"><div><p className="eyebrow">JURNAL OLAHRAGA</p><h2>Masukkan gerakmu.</h2><p className="section-intro">Simpan sesi olahraga secara sederhana. Data ini hanya tinggal di perangkatmu.</p></div><div className="training-count"><strong>{todayWorkouts.length}</strong><span>sesi hari ini</span></div></div><div className="training-layout"><form className="form-panel" onSubmit={addWorkout}><div className="panel-heading"><div><span className="number-badge">01</span><h3>Tambahkan sesi</h3></div><Zap size={19} /></div><label>Jenis aktivitas<input name="activity" required placeholder="Contoh: Jalan sore, yoga, gym" /></label><div className="form-row"><label>Durasi (menit)<input name="duration" required min="1" type="number" placeholder="30" /></label><label>Intensitas<select name="intensity" defaultValue="sedang"><option value="ringan">Ringan</option><option value="sedang">Sedang</option><option value="berat">Berat</option></select></label></div><label>Catatan kecil<textarea name="note" rows={3} placeholder="Apa yang kamu rasakan setelah bergerak?" /></label><button className="primary-button" type="submit"><Plus size={16} /> Simpan sesi</button></form><div className="workout-history"><div className="panel-heading"><div><p className="eyebrow">{todayWorkouts.length ? "HARI INI" : "RUANG KOSONG"}</p><h3>{todayWorkouts.length ? "Jejak gerakmu" : "Belum ada sesi"}</h3></div><Trophy size={19} /></div>{todayWorkouts.length ? <div className="workout-list">{todayWorkouts.map((workout) => <WorkoutRow key={workout.id} workout={workout} onDelete={removeWorkout} />)}</div> : <EmptyState onAdd={() => document.querySelector<HTMLInputElement>('input[name="activity"]')?.focus()} />}</div></div></section>}

        {tab === "health" && <section className="page-layout"><div className="section-heading"><div><p className="eyebrow">CHECK-IN TUBUH</p><h2>Bagaimana rasanya hari ini?</h2><p className="section-intro">Tidak semua hal harus diperbaiki. Beberapa cukup didengarkan.</p></div><HeartPulse className="heading-symbol" size={30} /></div><div className="health-grid"><article className="health-panel health-panel--water"><div className="panel-heading"><div><p className="eyebrow">HIDRASI</p><h3>Air yang masuk</h3></div><Droplets size={20} /></div><div className="water-number"><strong>{state.water}</strong><span>/ 8 gelas</span></div><div className="water-bar"><span style={{ width: `${(state.water / waterGoal) * 100}%` }} /></div><div className="quick-actions"><button onClick={() => addWater(-1)} disabled={state.water === 0}>−</button><button className="water-add" onClick={() => addWater(1)}>+ 1 gelas</button><button onClick={() => addWater(1)} aria-label="Tambah segelas air">+</button></div></article><article className="health-panel health-panel--sleep"><div className="panel-heading"><div><p className="eyebrow">ISTIRAHAT</p><h3>Jam tidur</h3></div><Moon size={20} /></div><div className="sleep-control"><strong>{state.sleep}</strong><span>jam</span></div><input aria-label="Jam tidur" type="range" min="0" max="12" step="0.5" value={state.sleep} onChange={(event) => updateState({ sleep: Number(event.target.value) })} /><div className="track-labels"><span>0j</span><span>12j</span></div><p className="panel-note">Geser sesuai tidurmu semalam. Tidak apa-apa jika belum ideal.</p></article><article className="health-panel health-panel--mood"><div className="panel-heading"><div><p className="eyebrow">SUASANA</p><h3>Energi emosimu</h3></div><Sparkles size={20} /></div><div className="mood-grid">{(Object.keys(moodLabels) as Exclude<Mood, null>[]).map((mood) => <button key={mood} className={state.mood === mood ? "is-selected" : ""} onClick={() => updateState({ mood })}><span className={`mood-orb mood-orb--${mood}`} />{moodLabels[mood]}{state.mood === mood && <Check size={14} />}</button>)}</div></article><article className="health-panel health-panel--note"><div className="panel-heading"><div><p className="eyebrow">CATATAN TUBUH</p><h3>Satu kalimat yang jujur</h3></div><Utensils size={20} /></div><textarea value={state.healthNote} onChange={(event) => updateState({ healthNote: event.target.value })} rows={5} placeholder="Contoh: Bahuku lebih ringan setelah jalan pagi." /><span className="save-hint">Tersimpan otomatis di perangkat</span></article></div></section>}
      </main>
    </div>
  );
}

function WorkoutRow({ workout, onDelete }: { workout: Workout; onDelete: (id: string) => void }) {
  return <article className="workout-row"><div className="workout-symbol"><Activity size={16} /></div><div className="workout-copy"><h4>{workout.activity}</h4><p><Clock3 size={12} /> {workout.duration} menit <span>·</span> {intensityLabels[workout.intensity]}</p>{workout.note && <small>{workout.note}</small>}</div><button className="icon-button" aria-label={`Hapus ${workout.activity}`} onClick={() => onDelete(workout.id)}><Trash2 size={15} /></button></article>;
}

function EmptyState({ onAdd }: { onAdd: () => void }) {
  return <div className="empty-state"><div className="empty-symbol"><Target size={20} /></div><div><h3>Belum ada jejak hari ini.</h3><p>Mulai dari sesuatu yang terasa mungkin dilakukan.</p></div><button className="text-button" onClick={onAdd}>Tambah <ChevronRight size={15} /></button></div>;
}
